-- Scenario 1: Books and Authors
-- One author can have multiple books (One-to-Many relationship)

-- Create Authors table
CREATE TABLE Authors (
    author_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    nationality TEXT
);

-- Create Books table with Foreign Key
CREATE TABLE Books (
    book_id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    publish_year INTEGER,
    author_id INTEGER,
    FOREIGN KEY (author_id) REFERENCES Authors(author_id)
);

-- Insert sample data into Authors
INSERT INTO Authors (name, nationality) VALUES ('J.K. Rowling', 'British');
INSERT INTO Authors (name, nationality) VALUES ('George R.R. Martin', 'American');
INSERT INTO Authors (name, nationality) VALUES ('Haruki Murakami', 'Japanese');

-- Insert sample data into Books
INSERT INTO Books (title, publish_year, author_id) VALUES ('Harry Potter and the Philosopher''s Stone', 1997, 1);
INSERT INTO Books (title, publish_year, author_id) VALUES ('A Game of Thrones', 1996, 2);
INSERT INTO Books (title, publish_year, author_id) VALUES ('Norwegian Wood', 1987, 3);
INSERT INTO Books (title, publish_year, author_id) VALUES ('Kafka on the Shore', 2002, 3);

-- SELECT query to join tables and show books with their authors
SELECT Books.title, Books.publish_year, Authors.name AS author_name
FROM Books
JOIN Authors ON Books.author_id = Authors.author_id;
