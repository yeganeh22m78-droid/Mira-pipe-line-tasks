-- Scenario 2: Departments and Employees
-- One department can have multiple employees (One-to-Many relationship)

-- Create Departments table
CREATE TABLE Departments (
    dept_id INTEGER PRIMARY KEY AUTOINCREMENT,
    dept_name TEXT NOT NULL,
    location TEXT
);

-- Create Employees table with Foreign Key
CREATE TABLE Employees (
    emp_id INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    salary REAL,
    dept_id INTEGER,
    FOREIGN KEY (dept_id) REFERENCES Departments(dept_id)
);

-- Insert sample data into Departments
INSERT INTO Departments (dept_name, location) VALUES ('Engineering', 'New York');
INSERT INTO Departments (dept_name, location) VALUES ('Marketing', 'San Francisco');
INSERT INTO Departments (dept_name, location) VALUES ('Human Resources', 'Chicago');

-- Insert sample data into Employees
INSERT INTO Employees (first_name, last_name, salary, dept_id) VALUES ('Alice', 'Johnson', 85000, 1);
INSERT INTO Employees (first_name, last_name, salary, dept_id) VALUES ('Bob', 'Smith', 75000, 1);
INSERT INTO Employees (first_name, last_name, salary, dept_id) VALUES ('Charlie', 'Brown', 65000, 2);
INSERT INTO Employees (first_name, last_name, salary, dept_id) VALUES ('Diana', 'Prince', 70000, 3);

-- SELECT query to list employees and their department names
SELECT Employees.first_name, Employees.last_name, Departments.dept_name
FROM Employees
JOIN Departments ON Employees.dept_id = Departments.dept_id;
