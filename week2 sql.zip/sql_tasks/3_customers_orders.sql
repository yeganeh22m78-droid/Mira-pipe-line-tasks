-- Scenario 3: Customers and Orders
-- One customer can place multiple orders (One-to-Many relationship)

-- Create Customers table
CREATE TABLE Customers (
    customer_id INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    email TEXT UNIQUE
);

-- Create Orders table with Foreign Key
CREATE TABLE Orders (
    order_id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_date DATE DEFAULT CURRENT_DATE,
    total_amount REAL,
    customer_id INTEGER,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
);

-- Insert sample data into Customers
INSERT INTO Customers (first_name, last_name, email) VALUES ('John', 'Doe', 'john.doe@example.com');
INSERT INTO Customers (first_name, last_name, email) VALUES ('Jane', 'Smith', 'jane.smith@example.com');
INSERT INTO Customers (first_name, last_name, email) VALUES ('Michael', 'Scott', 'm.scott@dundermifflin.com');

-- Insert sample data into Orders
INSERT INTO Orders (total_amount, customer_id) VALUES (150.50, 1);
INSERT INTO Orders (total_amount, customer_id) VALUES (89.99, 1);
INSERT INTO Orders (total_amount, customer_id) VALUES (210.00, 2);
INSERT INTO Orders (total_amount, customer_id) VALUES (45.00, 3);

-- SELECT query to show all orders with customer names
SELECT Orders.order_id, Orders.order_date, Orders.total_amount, Customers.first_name, Customers.last_name
FROM Orders
JOIN Customers ON Orders.customer_id = Customers.customer_id;
