-- Scenario 5: Directors and Movies
-- One director can direct multiple movies (One-to-Many relationship)

-- Create Directors table
CREATE TABLE Directors (
    director_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    birth_year INTEGER
);

-- Create Movies table with Foreign Key
CREATE TABLE Movies (
    movie_id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    release_year INTEGER,
    genre TEXT,
    director_id INTEGER,
    FOREIGN KEY (director_id) REFERENCES Directors(director_id)
);

-- Insert sample data into Directors
INSERT INTO Directors (name, birth_year) VALUES ('Christopher Nolan', 1970);
INSERT INTO Directors (name, birth_year) VALUES ('Quentin Tarantino', 1963);
INSERT INTO Directors (name, birth_year) VALUES ('Greta Gerwig', 1983);

-- Insert sample data into Movies
INSERT INTO Movies (title, release_year, genre, director_id) VALUES ('Inception', 2010, 'Sci-Fi', 1);
INSERT INTO Movies (title, release_year, genre, director_id) VALUES ('Interstellar', 2014, 'Sci-Fi', 1);
INSERT INTO Movies (title, release_year, genre, director_id) VALUES ('Pulp Fiction', 1994, 'Crime', 2);
INSERT INTO Movies (title, release_year, genre, director_id) VALUES ('Barbie', 2023, 'Comedy', 3);

-- SELECT query to list movies with their directors and release years
SELECT Movies.title, Movies.release_year, Directors.name AS director_name
FROM Movies
JOIN Directors ON Movies.director_id = Directors.director_id;
