-- Scenario 4: Consultant and Meetings
-- One consultant can have multiple meetings (One-to-Many relationship)

-- Create Consultants table
CREATE TABLE Consultants (
    consultant_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    specialization TEXT
);

-- Create Meetings table with Foreign Key
CREATE TABLE Meetings (
    meeting_id INTEGER PRIMARY KEY AUTOINCREMENT,
    meeting_date DATE,
    client_name TEXT,
    consultant_id INTEGER,
    FOREIGN KEY (consultant_id) REFERENCES Consultants(consultant_id)
);

-- Insert sample data into Consultants
INSERT INTO Consultants (name, specialization) VALUES ('Robert Kiyosaki', 'Financial Education');
INSERT INTO Consultants (name, specialization) VALUES ('Simon Sinek', 'Leadership');
INSERT INTO Consultants (name, specialization) VALUES ('Brené Brown', 'Psychology');

-- Insert sample data into Meetings
INSERT INTO Meetings (meeting_date, client_name, consultant_id) VALUES ('2026-05-10', 'ABC Corp', 1);
INSERT INTO Meetings (meeting_date, client_name, consultant_id) VALUES ('2026-05-12', 'XYZ Ltd', 1);
INSERT INTO Meetings (meeting_date, client_name, consultant_id) VALUES ('2026-05-15', 'Global Inc', 2);
INSERT INTO Meetings (meeting_date, client_name, consultant_id) VALUES ('2026-05-20', 'Personal Coaching', 3);

-- SELECT query to list meetings with consultant names and specializations
SELECT Meetings.meeting_date, Meetings.client_name, Consultants.name AS consultant_name, Consultants.specialization
FROM Meetings
JOIN Consultants ON Meetings.consultant_id = Consultants.consultant_id;
