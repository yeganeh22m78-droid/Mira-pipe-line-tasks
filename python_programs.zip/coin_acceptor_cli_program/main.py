from coin_acceptor import CoinAcceptor

def main():
    print("Program starting.")
    print("Welcome to coin acceptor program.")
    coin_acceptor = CoinAcceptor()
    print("Insert new coin by typing it's value (0 returns the money, -1 exits the program)")

    while True:
        try:
            choice_str = input("Insert coin(0 return, -1 exit): ")
            choice = float(choice_str)
            
            if choice == -1:
                print("Exiting program.")
                print("Program ending.")
                print("Thank you for using the program!")
                break
            elif choice == 0:
                print("Returning coins...")
                amount, value = coin_acceptor.returnCoins()
                print(f"{amount} coins with {value}€ value returned.")
                print(f"Inserted coins = 0, value = 0€")
            else:
                print("Inserting...")
                coin_acceptor.insertCoin(choice)
                print(f"Inserted coins = {coin_acceptor.getAmount()}, value = {coin_acceptor.getValue()}€")
        except ValueError:
            print("Invalid input. Please enter a number.")
        except EOFError:
            break

if __name__ == "__main__":
    main()
