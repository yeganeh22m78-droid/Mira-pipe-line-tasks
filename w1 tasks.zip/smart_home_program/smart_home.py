class SmartDevice:
    def __init__(self, deviceName):
        self.deviceName = deviceName
        self.status = "OFF"

    def operate(self):
        pass

class SmartLight(SmartDevice):
    def __init__(self, deviceName, brightness=100):
        super().__init__(deviceName)
        self.brightness = brightness

    def operate(self):
        self.status = "ON"
        return f"SmartLight '{self.deviceName}' is now ON with {self.brightness}% brightness."

class SmartThermostat(SmartDevice):
    def __init__(self, deviceName, temperature=22):
        super().__init__(deviceName)
        self.temperature = temperature

    def operate(self):
        self.status = "ACTIVE"
        return f"SmartThermostat '{self.deviceName}' is setting temperature to {self.temperature}°C."

class SmartLock(SmartDevice):
    def __init__(self, deviceName):
        super().__init__(deviceName)
        self.is_locked = True

    def operate(self):
        self.is_locked = not self.is_locked
        self.status = "LOCKED" if self.is_locked else "UNLOCKED"
        return f"SmartLock '{self.deviceName}' is now {self.status}."

def operate_all_devices(devices):
    if not devices:
        print("No devices to operate!")
        return
    
    print("\n--- Operating Smart Home Devices ---")
    for device in devices:
        print(device.operate())
    print("--- All operations complete ---\n")
