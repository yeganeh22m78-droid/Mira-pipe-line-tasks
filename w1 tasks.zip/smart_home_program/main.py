from smart_home import SmartLight, SmartThermostat, SmartLock, operate_all_devices

def main():
    devices = []
    
    while True:
        print("\nMenu:")
        print("1 - Add Smart Device")
        print("2 - Operate Devices")
        print("0 - Exit")
        
        choice = input("Choice: ")
        
        if choice == '1':
            print("1 - Smart Light")
            print("2 - Smart Thermostat")
            print("3 - Smart Lock")
            type_choice = input("Device Type: ")
            name = input("Device Name: ")
            
            if type_choice == '1':
                brightness = int(input("Brightness (0-100): "))
                devices.append(SmartLight(name, brightness))
            elif type_choice == '2':
                temp = int(input("Temperature (°C): "))
                devices.append(SmartThermostat(name, temp))
            elif type_choice == '3':
                devices.append(SmartLock(name))
            else:
                print("Invalid device type.")
                
        elif choice == '2':
            operate_all_devices(devices)
            
        elif choice == '0':
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
