from vr_entities import Player, NPC, Object, interact_with_all

def main():
    entities = []
    
    while True:
        print("\nMenu:")
        print("1 - Add Entity")
        print("2 - Interact with Entities")
        print("3 - Exit")
        
        choice = input("Choice: ")
        
        if choice == '1':
            print("1 - Player")
            print("2 - NPC")
            print("3 - Object")
            type_choice = input("Entity Type: ")
            name = input("Entity Name: ")
            x = float(input("Position X: "))
            y = float(input("Position Y: "))
            z = float(input("Position Z: "))
            pos = (x, y, z)
            
            if type_choice == '1':
                health = int(input("Health: "))
                entities.append(Player(name, pos, health))
            elif type_choice == '2':
                role = input("Role: ")
                entities.append(NPC(name, pos, role))
            elif type_choice == '3':
                movable = input("Is movable? (y/n): ").lower() == 'y'
                entities.append(Object(name, pos, movable))
            else:
                print("Invalid entity type.")
                
        elif choice == '2':
            interact_with_all(entities)
            
        elif choice == '3':
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
