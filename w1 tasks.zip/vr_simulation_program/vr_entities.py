class Entity:
    def __init__(self, name, position=(0, 0, 0)):
        self.name = name
        self.position = position

    def interact(self):
        pass

class Player(Entity):
    def __init__(self, name, position=(0, 0, 0), health=100):
        super().__init__(name, position)
        self.health = health

    def interact(self):
        return f"Player '{self.name}' at {self.position} waves hello!"

class NPC(Entity):
    def __init__(self, name, position=(0, 0, 0), role="Villager"):
        super().__init__(name, position)
        self.role = role

    def interact(self):
        return f"NPC '{self.name}' ({self.role}) at {self.position} says: 'Welcome to our village!'"

class Object(Entity):
    def __init__(self, name, position=(0, 0, 0), is_movable=True):
        super().__init__(name, position)
        self.is_movable = is_movable

    def interact(self):
        action = "moved" if self.is_movable else "examined"
        return f"Object '{self.name}' at {self.position} was {action}."

def interact_with_all(entities):
    if not entities:
        print("No entities in the simulation!")
        return
    
    print("\n--- VR Interaction Simulation ---")
    for entity in entities:
        print(entity.interact())
    print("--- End of Simulation ---\n")
