import csv
import base64

class IoTDevice:
    def __init__(self, deviceId, location, data):
        self.deviceId = deviceId
        self.location = location
        self.data = data

    def to_dict(self):
        return {
            'type': self.__class__.__name__,
            'deviceId': self.deviceId,
            'location': self.location,
            'data': self.data
        }

class TemperatureSensor(IoTDevice):
    pass

class HumiditySensor(IoTDevice):
    pass

class MotionSensor(IoTDevice):
    pass

class DataPipeline:
    @staticmethod
    def serialize_to_csv(devices, filename):
        with open(filename, mode='w', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=['type', 'deviceId', 'location', 'data'])
            writer.writeheader()
            for device in devices:
                writer.writerow(device.to_dict())

    @staticmethod
    def deserialize_from_csv(filename):
        devices = []
        try:
            with open(filename, mode='r') as file:
                reader = csv.DictReader(file)
                for row in reader:
                    device_type = row['type']
                    if device_type == 'TemperatureSensor':
                        devices.append(TemperatureSensor(row['deviceId'], row['location'], row['data']))
                    elif device_type == 'HumiditySensor':
                        devices.append(HumiditySensor(row['deviceId'], row['location'], row['data']))
                    elif device_type == 'MotionSensor':
                        devices.append(MotionSensor(row['deviceId'], row['location'], row['data']))
        except FileNotFoundError:
            print("CSV file not found.")
        return devices

    @staticmethod
    def encrypt_data(data):
        # Simple XOR encryption for demonstration
        key = "secret"
        encrypted = "".join(chr(ord(c) ^ ord(key[i % len(key)])) for i, c in enumerate(data))
        return base64.b64encode(encrypted.encode()).decode()

    @staticmethod
    def decrypt_data(encrypted_data):
        key = "secret"
        decoded = base64.b64decode(encrypted_data.encode()).decode()
        decrypted = "".join(chr(ord(c) ^ ord(key[i % len(key)])) for i, c in enumerate(decoded))
        return decrypted
