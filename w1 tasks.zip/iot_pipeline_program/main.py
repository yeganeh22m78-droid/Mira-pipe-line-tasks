from iot_devices import TemperatureSensor, HumiditySensor, MotionSensor, DataPipeline

def main():
    devices = []
    csv_filename = "iot_data.csv"
    
    while True:
        print("\nMenu:")
        print("1 - Add IoT Device")
        print("2 - Serialize Data")
        print("3 - Deserialize Data")
        print("4 - Encrypt Data")
        print("5 - Decrypt Data")
        print("0 - Exit")
        
        choice = input("Choice: ")
        
        if choice == '1':
            print("1 - Temperature Sensor")
            print("2 - Humidity Sensor")
            print("3 - Motion Sensor")
            type_choice = input("Device Type: ")
            device_id = input("Device ID: ")
            location = input("Location: ")
            data = input("Data: ")
            
            if type_choice == '1':
                devices.append(TemperatureSensor(device_id, location, data))
            elif type_choice == '2':
                devices.append(HumiditySensor(device_id, location, data))
            elif type_choice == '3':
                devices.append(MotionSensor(device_id, location, data))
            else:
                print("Invalid device type.")
                
        elif choice == '2':
            DataPipeline.serialize_to_csv(devices, csv_filename)
            print(f"Data serialized to {csv_filename}")
            
        elif choice == '3':
            devices = DataPipeline.deserialize_from_csv(csv_filename)
            print(f"Data deserialized from {csv_filename}")
            for device in devices:
                print(f"{device.__class__.__name__}: ID={device.deviceId}, Location={device.location}, Data={device.data}")
                
        elif choice == '4':
            data_to_encrypt = input("Enter data to encrypt: ")
            encrypted = DataPipeline.encrypt_data(data_to_encrypt)
            print(f"Encrypted: {encrypted}")
            
        elif choice == '5':
            data_to_decrypt = input("Enter data to decrypt: ")
            try:
                decrypted = DataPipeline.decrypt_data(data_to_decrypt)
                print(f"Decrypted: {decrypted}")
            except Exception as e:
                print(f"Decryption failed: {e}")
                
        elif choice == '0':
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
