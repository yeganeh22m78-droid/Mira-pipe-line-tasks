from game_characters import Warrior, Mage, Archer, simulate_battle

def main():
    characters = []
    
    while True:
        print("\nMenu:")
        print("1 - Create Character")
        print("2 - Simulate Battle")
        print("0 - Exit")
        
        choice = input("Choice: ")
        
        if choice == '1':
            print("1 - Warrior")
            print("2 - Mage")
            print("3 - Archer")
            type_choice = input("Character Type: ")
            name = input("Character Name: ")
            
            if type_choice == '1':
                characters.append(Warrior(name))
            elif type_choice == '2':
                characters.append(Mage(name))
            elif type_choice == '3':
                characters.append(Archer(name))
            else:
                print("Invalid character type.")
                
        elif choice == '2':
            simulate_battle(characters)
            
        elif choice == '0':
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
