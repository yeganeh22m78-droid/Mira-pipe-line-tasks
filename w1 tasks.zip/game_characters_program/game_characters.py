from abc import ABC, abstractmethod

class GameCharacter(ABC):
    def __init__(self, name):
        self.name = name

    @abstractmethod
    def attack(self):
        pass

    @abstractmethod
    def defend(self):
        pass

class Warrior(GameCharacter):
    def attack(self):
        return f"{self.name} swings a mighty sword!"

    def defend(self):
        return f"{self.name} raises a heavy shield!"

class Mage(GameCharacter):
    def attack(self):
        return f"{self.name} casts a powerful fireball!"

    def defend(self):
        return f"{self.name} creates a magical barrier!"

class Archer(GameCharacter):
    def attack(self):
        return f"{self.name} shoots a precise arrow!"

    def defend(self):
        return f"{self.name} dodges with agility!"

def simulate_battle(characters):
    if not characters:
        print("No characters to battle!")
        return
    
    print("\n--- Battle Simulation ---")
    for char in characters:
        print(char.attack())
        print(char.defend())
    print("--- End of Battle ---\n")
