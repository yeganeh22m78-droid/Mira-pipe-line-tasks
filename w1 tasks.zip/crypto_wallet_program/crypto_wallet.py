import datetime

class CryptoWallet:
    def __init__(self, walletId, initial_balance=0.0):
        self._walletId = walletId
        self._balance = initial_balance
        self._transaction_history = []
        self._add_transaction("Wallet Created", initial_balance)

    def _add_transaction(self, type, amount):
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self._transaction_history.append({
            'timestamp': timestamp,
            'type': type,
            'amount': amount,
            'balance_after': self._balance
        })

    def deposit(self, amount):
        if amount > 0:
            self._balance += amount
            self._add_transaction("Deposit", amount)
            return True
        return False

    def withdraw(self, amount):
        if 0 < amount <= self._balance:
            self._balance -= amount
            self._add_transaction("Withdrawal", amount)
            return True
        return False

    def check_balance(self):
        return self._balance

    def get_transaction_history(self):
        return self._transaction_history

    def get_wallet_id(self):
        return self._walletId
