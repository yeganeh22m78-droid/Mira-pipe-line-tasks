from crypto_wallet import CryptoWallet

def main():
    wallets = {}
    current_wallet_id = None
    
    while True:
        print("\nMenu:")
        print("1 - Create Wallet")
        print("2 - Deposit")
        print("3 - Withdraw")
        print("4 - Check Balance")
        print("5 - Transaction History")
        print("0 - Exit")
        
        choice = input("Choice: ")
        
        if choice == '1':
            wallet_id = input("Enter Wallet ID: ")
            if wallet_id in wallets:
                print("Wallet ID already exists.")
            else:
                initial_balance = float(input("Initial Balance: "))
                wallets[wallet_id] = CryptoWallet(wallet_id, initial_balance)
                current_wallet_id = wallet_id
                print(f"Wallet '{wallet_id}' created.")
                
        elif choice in ['2', '3', '4', '5']:
            if not wallets:
                print("No wallets created yet.")
                continue
            
            if current_wallet_id is None or current_wallet_id not in wallets:
                current_wallet_id = input("Enter Wallet ID to use: ")
                if current_wallet_id not in wallets:
                    print("Wallet not found.")
                    continue
            
            wallet = wallets[current_wallet_id]
            
            if choice == '2':
                amount = float(input("Enter amount to deposit: "))
                if wallet.deposit(amount):
                    print(f"Deposited {amount}. New balance: {wallet.check_balance()}")
                else:
                    print("Invalid deposit amount.")
                    
            elif choice == '3':
                amount = float(input("Enter amount to withdraw: "))
                if wallet.withdraw(amount):
                    print(f"Withdrew {amount}. New balance: {wallet.check_balance()}")
                else:
                    print("Insufficient funds or invalid amount.")
                    
            elif choice == '4':
                print(f"Wallet ID: {wallet.get_wallet_id()}")
                print(f"Current Balance: {wallet.check_balance()}")
                
            elif choice == '5':
                print(f"\n--- Transaction History for {wallet.get_wallet_id()} ---")
                for tx in wallet.get_transaction_history():
                    print(f"[{tx['timestamp']}] {tx['type']}: {tx['amount']} (Balance: {tx['balance_after']})")
                print("--- End of History ---\n")
                
        elif choice == '0':
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
